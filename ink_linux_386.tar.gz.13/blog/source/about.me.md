type: page
title: "关于作者"
author: me

---

## 纸小墨

构建只为纯粹书写的博客。

[http://www.chole.io/](http://www.chole.io/)